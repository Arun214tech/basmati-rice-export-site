import React, { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

export default function HomePage() {
  const [showChat, setShowChat] = useState(false);

  return (
    <div className="min-h-screen bg-white text-gray-900 p-6">
      <header className="text-center mb-10">
        <h1 className="text-4xl font-bold mb-2">Royal Aroma Basmati Exports</h1>
        <p className="text-lg">Pure Indian Basmati Rice, Delivered Worldwide</p>
      </header>

      <section className="grid md:grid-cols-2 gap-6 mb-12">
        <Card>
          <CardContent className="p-6">
            <h2 className="text-2xl font-semibold mb-4">Our Premium Rice Varieties</h2>
            <ul className="list-disc list-inside">
              <li>India Gate Classic Basmati</li>
              <li>India Gate Tibar Basmati</li>
              <li>India Gate Golden Sella</li>
              <li>India Gate Dubar Basmati</li>
            </ul>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <h2 className="text-2xl font-semibold mb-4">Export Information</h2>
            <p>
              We export to over 40 countries. Minimum order quantity is 1 metric ton.
              Packaging options include 1kg, 5kg, 10kg, and 25kg. All shipments are
              handled through certified logistic partners with full tracking.
            </p>
          </CardContent>
        </Card>
      </section>

      <section className="mb-12">
        <Card>
          <CardContent className="p-6">
            <h2 className="text-2xl font-semibold mb-4">Get a Quote</h2>
            <form className="grid gap-4 md:grid-cols-2">
              <Input placeholder="Your Name" />
              <Input placeholder="Email Address" type="email" />
              <Input placeholder="Country" />
              <Input placeholder="Required Quantity (MT)" type="number" />
              <Button className="col-span-2 mt-4">Request Quote</Button>
            </form>
          </CardContent>
        </Card>
      </section>

      <section className="text-center">
        <h2 className="text-2xl font-semibold mb-2">Need Help?</h2>
        <p className="mb-4">Ask our AI-powered assistant anything about our products or exports.</p>
        <Button variant="outline" onClick={() => setShowChat(!showChat)}>
          {showChat ? "Close Chat" : "Chat with AI Assistant"}
        </Button>
      </section>

      {showChat && (
        <div className="fixed bottom-6 right-6 bg-white rounded-2xl shadow-xl w-80 h-96 p-4 flex flex-col">
          <div className="text-lg font-semibold mb-2">AI Assistant</div>
          <div className="flex-1 overflow-y-auto border p-2 text-sm mb-2">
            <p><strong>User:</strong> What types of Basmati rice do you offer?</p>
            <p><strong>AI:</strong> We offer India Gate Classic, Tibar, Golden Sella, and Dubar varieties.</p>
            <p><strong>User:</strong> What’s the minimum export quantity?</p>
            <p><strong>AI:</strong> Our minimum order quantity is 1 metric ton.</p>
          </div>
          <input className="border rounded px-2 py-1 text-sm" placeholder="Type your question..." />
        </div>
      )}
    </div>
  );
}
